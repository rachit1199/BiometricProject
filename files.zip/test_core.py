import numpy as np
import config as cfg, fusion, store, voice, face, speech


def test_fusion_zones():
    assert fusion.decide(0.95, 0.95)[0] == "grant"
    assert fusion.decide(0.7, 0.6)[0] == "otp"
    assert fusion.decide(0.3, 0.3)[0] == "reject"
    assert fusion.decide(0.99, 0.1)[0] == "reject"


def test_adaptive_weights_favour_good_modality():
    wf, wv = fusion.weights(q_face=0.2, q_voice=1.0)
    assert wv > wf and abs(wf + wv - 1) < 1e-9


def test_risk_raises_grant_bar():
    assert fusion.decide(0.8, 0.8, recent_failures=0)[0] == "grant"
    assert fusion.decide(0.77, 0.77, recent_failures=2)[0] == "otp"


def test_lockout_otp_single_use():
    u = "tester_lock"
    for _ in range(cfg.MAX_FAILED_ATTEMPTS):
        store.register_failure(u)
    assert store.locked(u)
    code = store.issue_otp("tester_otp")
    assert not store.check_otp("tester_otp", "000000" if code != "000000" else "111111")
    assert store.check_otp("tester_otp", code)
    assert not store.check_otp("tester_otp", code)


def test_challenge_single_use_and_bound_to_user():
    cid, _ = store.issue_challenge("alice")
    assert store.consume_challenge("bob", cid) is None
    cid, digits = store.issue_challenge("alice")
    assert store.consume_challenge("alice", cid) == digits
    assert store.consume_challenge("alice", cid) is None


def test_session_lifecycle():
    t = store.issue_session("carol")
    assert store.session_user(t) == "carol"
    store.end_session(t)
    assert store.session_user(t) is None


def _tone(f=200, sec=3, noise=0.01, seed=0):
    r = np.random.default_rng(seed); t = np.arange(int(sec * 16000)) / 16000
    y = 0.3 * np.sin(2 * np.pi * f * t) * (np.sin(2 * np.pi * 3 * t) > -0.2) + noise * r.standard_normal(len(t))
    return y.astype(np.float32)


def test_voice_quality_and_replay():
    f = voice.features(_tone())
    assert f.shape == (76,)
    assert voice.check_quality(np.zeros(48000, dtype=np.float32))[0] is False
    assert voice.is_replay(f, [f.copy()], np.ones_like(f))
    assert not voice.is_replay(f, [f + 5], np.ones_like(f))


def test_voice_matching_separates_speakers():
    vp = voice.build_voiceprint([voice.features(_tone(200, seed=i)) for i in range(3)])
    assert voice.match(vp, _tone(200, seed=9))[0] > voice.match(vp, _tone(420, seed=9))[0]


def test_liveness_rejects_frozen_frames():
    crop = (np.random.default_rng(1).random((100, 100)) * 255).astype(np.uint8)
    infos = [{"crop": crop, "cx": .5, "cy": .5, "w": .3, "eyes": 2} for _ in range(8)]
    ok, info = face.liveness(infos)
    assert not ok and "motion" in info["failed"]


def test_blink_detector():
    assert face._blinked([2, 2, 0, 2, 2]) and not face._blinked([2, 2, 2, 2])


def test_asr_digit_parsing():
    assert speech.text_to_digits("one two three, four 5 six") == "123456"
    assert speech.verify_digits(None, "123456") is None


def test_api_basics():
    import app as A
    c = A.app.test_client()
    assert c.get("/api/health").get_json()["ok"]
    assert c.post("/api/login", json={"username": "ghost_user"}).status_code == 401
    assert c.post("/api/challenge", json={"username": "ghost_user"}).get_json()["digits"].isdigit()
    assert c.get("/api/session").status_code == 401
